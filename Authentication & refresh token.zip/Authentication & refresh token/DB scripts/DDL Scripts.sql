create table dbo.[User]
(
UserId int PRIMARY KEY DEFAULT (NEXT VALUE FOR SharedSequence),
 Username NVARCHAR(255) not null,
 PasswordSalt VARCHAR(max) not null,
 PasswordHash VARCHAR(max) not null,
 Role varchar(10) not null,
 recordcreationdate datetime default current_timestamp,
 recordmodifieddate datetime default current_timestamp
) 



Create table Course(
CourseId int PRIMARY KEY DEFAULT (NEXT VALUE FOR SharedSequence),
CourseName varchar(255) not null,
Courseduration datetime,
mode varchar(3),
recordcreationdate datetime default current_timestamp,
recordmodifieddate datetime default current_timestamp
)

create table Assessment(
AssessmentId int PRIMARY KEY DEFAULT (NEXT VALUE FOR SharedSequence),
AssessmentName varchar(255) not null,
Duration datetime,
numOfQuestions int,
startdate date,
recordcreationdate datetime default current_timestamp,
recordmodifieddate datetime default current_timestamp
)

create table Enrollment(
EnrollmentId int PRIMARY KEY DEFAULT (NEXT VALUE FOR SharedSequence),
UserId int,
CourseId int,
AssessmentId int,
EnrolledTime datetime,
recordcreationdate datetime default current_timestamp,
recordmodifieddate datetime default current_timestamp
)

ALTER TABLE Enrollment
ADD CONSTRAINT FK_Enroll_User FOREIGN KEY (UserId)
REFERENCES dbo.[User](UserId);

ALTER TABLE Enrollment
ADD CONSTRAINT FK_Enroll_Course FOREIGN KEY (CourseId)
REFERENCES Course(CourseId);

ALTER TABLE Enrollment
ADD CONSTRAINT FK_Enroll_Assessment FOREIGN KEY (AssessmentId)
REFERENCES Assessment(AssessmentId);

ALTER TABLE Enrollment
ADD CONSTRAINT UK_Enroll_UAC unique(UserId,CourseId,AssessmentId);

ALTER TABLE Enrollment
ADD CONSTRAINT default_time DEFAULT current_timestamp FOR EnrolledTime;
--------------------------------------------------------------------------------
Select * from Enrollment
Select * from Course
Select * from Assessment
Select * from [User]
--------------------------------------------------------------------------------
insert into course(CourseName, courseduration, mode) values
('Engineering 101','00:30','ONL'),('Culinary arts by Chef Sanjeev','02:00','OFF')

CREATE SEQUENCE SharedSequence
   START WITH 1
   INCREMENT BY 1
   MINVALUE 1
   NO MAXVALUE
   CACHE 10;

   DRop table Enrollment
   drop table course
   drop table Assessment
   drop table [User]