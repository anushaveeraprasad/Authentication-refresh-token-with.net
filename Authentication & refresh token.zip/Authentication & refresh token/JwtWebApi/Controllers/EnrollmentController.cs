﻿using Dapper;
using JwtWebApi.Classes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Security.Claims;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace JwtWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public EnrollmentController(IConfiguration config)
        {
            _configuration = config;
        }

        [HttpGet("get-all-enrollments-of-user/{userId}"), AllowAnonymous]
        public async Task<ActionResult> GetEnrollmentByUserId(int userId)
        {
            using(var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var enrollments= await connectionString.QueryAsync<Enrollment>("Select * from Enrollment where userid= @Userid",new {Userid= userId});
                return Ok(enrollments);
            }
        }

        // POST api/<EnrollmentController>
        [HttpPost("enroll-course/{courseid}"), Authorize(Roles ="user")]
        public async Task<ActionResult> EnrollCourse(int courseid)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var courseFound = await connectionString.QuerySingleOrDefaultAsync<Course>("Select * from Course where CourseId=@CourseId", new  { CourseId = courseid });
                if(courseFound != null)
                {
                    await connectionString.ExecuteAsync("insert into Enrollment(UserId, CourseId) values(@UserId, @CourseId)", new
                    {
                        UserId = Convert.ToInt32(User?.FindFirst(ClaimTypes.NameIdentifier).Value),
                        CourseId = courseid
                    });
                    return Ok($"You have been enrolled to the course  successfully ");
                }
                return BadRequest("Sorry we can't enroll you. There is no such course. Please provide correct course details");

            }
        }

        [HttpPost("enroll-assessment/{assessmentid}"), Authorize(Roles = "user")]
        public async Task<ActionResult> EnrollAssessment(int assessmentid)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var assessment = await connectionString.QuerySingleOrDefaultAsync<Assessment>("Select * from Assessment where AssessmentId=@AssessmentId", new { AssessmentId = assessmentid });
                if (assessment != null)
                {
                    await connectionString.ExecuteAsync("insert into Enrollment(UserId, AssessmentId) values(@UserId, @AssessmentId)", new
                    {
                        UserId = Convert.ToInt32(User?.FindFirst(ClaimTypes.NameIdentifier).Value),
                        AssessmentId = assessmentid
                    });
                    return Ok($"You have been enrolled to the Assessment  successfully ");
                }
                return BadRequest("Sorry we can't enroll you. There is no such assessment. Please provide correct details");

            }
        }

        // DELETE api/<EnrollmentController>/5
        [HttpDelete("withdraw-course/{id}"), Authorize(Roles = "user")]
        public async Task<ActionResult> WithdrawCourse(int id)
        {
            var userId = Convert.ToInt32(User?.FindFirst(ClaimTypes.NameIdentifier).Value);
            using (var connectionString=new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var enrollments = await connectionString.ExecuteAsync("Delete from Enrollment where UserId=@UserId and courseid=@CourseId", new { UserId = userId, CourseId = id });
                return enrollments == 0 ? BadRequest("There were no active enrollments found to be withdrawn") : Ok("Course enrollment has been withdrawn!!");
            }
        }

        [HttpDelete("withdraw-assessments/{id}"), Authorize(Roles = "user")]
        public async Task<ActionResult> WithdrawAssessment(int id)
        {
            var userId = Convert.ToInt32(User?.FindFirst(ClaimTypes.NameIdentifier).Value);
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var enrollments = await connectionString.ExecuteAsync("Delete from Enrollment where UserId=@UserId and assessmentid=@AssessmentId", new { UserId = userId, AssessmentId = id });
                return enrollments == 0 ? BadRequest("There were no active enrollments found to be withdrawn") : Ok("Assessment enrollment has been withdrawn!!");
            }
        }

    }
}
