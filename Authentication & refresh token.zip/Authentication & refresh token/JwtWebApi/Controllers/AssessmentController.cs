﻿using JwtWebApi.Classes;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using Dapper;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace JwtWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssessmentController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public AssessmentController(IConfiguration config)
        {
            _configuration = config;
        }
        // GET: api/<AssessmentController>
        [HttpGet("all-assessments") , Authorize(Roles ="Admin,user")]
        public async Task<ActionResult<Assessment>> GetAllAssessments()
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                return Ok( await connectionString.QueryAsync<Assessment>("Select * from Assessment"));
            }
        }

        // POST api/<AssessmentController>/add-assessment
        [HttpPost("add-assessment"), Authorize(Roles = "Admin")]
        public async Task<ActionResult<string>> AddAssessment(Assessment input)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var assessment = await connectionString.ExecuteAsync("insert into Assessment(AssessmentName,Duration,NumOfQuestions,StartDate) values(@AssessmentName,@Duration,@NumOfQuestions,@StartDate)", new { AssessmentName = input.AssessmentName, Duration = input.Duration, NumOfQuestions = input.NumOfQuestions, StartDate = input.StartDate });
                return Ok("Assessment details were added successfully");
            }
        }

        // PUT api/<AssessmentController>/5
        [HttpPut("update-assessment/{id}"), Authorize(Roles = "Admin")]
        public async Task<ActionResult<string>> UpdateAssessment(int id, Assessment input)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var result = await connectionString.ExecuteAsync("Update Assessment set Assessmentname= @AssessmentName, Duration=@Duration, NumOfQuestions=@NumOfQuestions, StartDate=@StartDate where AssessmentId=@Id", new { AssessmentName = input.AssessmentName, Duration = input.Duration, NumOfQuestions = input.NumOfQuestions, StartDate = input.StartDate, Id = id });
                return result <= 0 ? NotFound("Updation Failed") : Ok("Assessment Updated Successfully");
            }
        }

        // DELETE api/<AssessmentController>/5
        [HttpDelete("{id}"), Authorize(Roles = "Admin")]
        public async Task<ActionResult<string>> DeleteAssessment(int id)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var result = await connectionString.ExecuteAsync("Delete from Assessment where AssessmentId=@Id", new { Id = id });
                return result <= 0 ? NotFound("Deletion Failed") : Ok("Assessment Deleted Successfully");
            }
        }
    }
}
