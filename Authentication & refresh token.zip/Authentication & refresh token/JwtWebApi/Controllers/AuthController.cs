﻿using Dapper;
using JwtWebApi;
using JwtWebApi.Classes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Collections;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace JwtWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        //private MyDbContext _dbContext;
        //public static List<User> users= new List<User>();
        private readonly IConfiguration _configuration;
        public AuthController( IConfiguration config)
        {
            _configuration = config;
        }
        //private void GetUserData()
        //{
        //    using (var dbContext = new MyDbContext(_configuration))
        //    {
        //        // LINQ query to get all data from the table
        //        users = dbContext.Users.ToList();
        //    }

        //}

        [HttpPost("register")]
        public async Task<ActionResult<User>> Register(UserRegister request)
        {
            CreatePassword(request.Password, out byte[] hash, out byte[] salt);
            string base64PasswordHash = Convert.ToBase64String(hash);
            string base64PasswordSalt = Convert.ToBase64String(salt);

            using (var connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                connection.Open();

                var newUser = await connection.QueryFirstOrDefaultAsync<User>("SELECT * FROM [User] WHERE Username = @Username", new { Username = request.Username });

                if (newUser != null)
                {
                    return BadRequest("User is already registered. Please login");
                }

                await connection.ExecuteAsync(
                    "INSERT INTO [User] (Username, PasswordSalt, PasswordHash,Role) VALUES (@Username, @Salt, @Hash,@Role)",
                    new { Username = request.Username, Salt = base64PasswordSalt, Hash = base64PasswordHash ,Role=request.Role});

                return Ok("User Registered Successfully");
            }
        }

        [HttpPost("login")]
        public async Task<ActionResult<string>> Login(UserRegister request)
        {
           
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                User user = await connectionString.QueryFirstOrDefaultAsync<User>($"Select * from [User] where username like '{request.Username}'");
                
                if (user is null)
                {
                    return BadRequest("User not found");
                }
                byte[] encodedHash = Convert.FromBase64String(user.PasswordHash);
                byte[] encodedSalt = Convert.FromBase64String(user.PasswordSalt);
                if (!VerifyPassword(request.Password, encodedHash, encodedSalt))
                {
                    return BadRequest("Wrong Password");
                }
                string token = CreateToken(user);
                var refreshToken = GenerateRefreshToken();
                var newRefreshToken=SetRefreshToken(refreshToken);
                UpdateRefreshToken(refreshToken, user.UserId);
                //await connectionString.ExecuteAsync("Update [User] set RefreshToken=@RefreshToken,TokenCreated=@TokenCreated, TokenExpires=@TokenExpires where UserId=@UserId",
                //    new
                //    {
                //        RefreshToken = newRefreshToken.Token,
                //        TokenCreated = newRefreshToken.Created,
                //        TokenExpires = newRefreshToken.Expires,
                //        UserId = user.UserId
                //    });

                return Ok($"Login successful \n {token}");
            }
        }
        [HttpPost("refresh-token"),AllowAnonymous]
        public async Task<ActionResult<string>> RefreshToken()
        {
            var refreshToken = Request.Cookies["refreshToken"];
            using(var connectionString=new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                
                var user = await connectionString.QueryFirstOrDefaultAsync<User>("Select * from [User] where RefreshToken=@RefreshToken",
                    new
                    {
                        RefreshToken=refreshToken
                        //Id = Convert.ToInt32(User?.FindFirst(ClaimTypes.NameIdentifier).Value)

                    });

                if(user is null)
                {
                    return Unauthorized("Refresh Token Not found");
                }
                else
                {
                    if (!user.RefreshToken.Equals(refreshToken))
                    {
                        return Unauthorized("Invalid Refresh Token");
                    }
                    else if (user.TokenExpires < DateTime.Now)
                    {
                        return Unauthorized("Refresh Token Expired");
                    }
                    string newToken = CreateToken(user);
                    var newRefreshToken = GenerateRefreshToken();
                    SetRefreshToken(newRefreshToken);
                    UpdateRefreshToken(newRefreshToken, user.UserId);
                    return Ok(newToken);
                }
                //if (User.Identity.IsAuthenticated && user!=null)
                //{
                    //if(user.UserId!= Convert.ToInt32(User?.FindFirst(ClaimTypes.NameIdentifier).Value))
                    //{
                        //return Unauthorized("Refresh token in memory doesn't match with the user logged in. So, new token cannot be generated");
                    //}
                
                
                //}
                //return Unauthorized("User is not logged in to refresh the token");
                
                
            }

        }
        private void UpdateRefreshToken(RefreshToken newRefreshToken, int userId)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
               var x= connectionString.ExecuteAsync("Update [User] set RefreshToken=@RefreshToken,TokenCreated=@TokenCreated, TokenExpires=@TokenExpires where UserId=@UserId",
                    new
                    {
                        RefreshToken = newRefreshToken.Token,
                        TokenCreated = newRefreshToken.Created,
                        TokenExpires = newRefreshToken.Expires,
                        UserId = userId
                    });
            }
        }
        private RefreshToken GenerateRefreshToken()
        {
            var refreshToken = new RefreshToken
            {
                Token = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64)),
                Expires = DateTime.Now.AddMinutes(10),
                Created = DateTime.Now
            };
            return refreshToken;
        }
        private RefreshToken SetRefreshToken(RefreshToken newRefreshToken)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = newRefreshToken.Expires
                
            };
            Response.Cookies.Append("refreshToken",newRefreshToken.Token,cookieOptions);
            return newRefreshToken;
        }
        private string CreateToken(User user)
        {
            List<Claim> claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString())
            };
            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(_configuration.GetSection("Token:MySecretKey").Value));
            var cred = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);
            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddMinutes(2),
                signingCredentials: cred);
            var jwt= new JwtSecurityTokenHandler().WriteToken(token);
            return jwt;
        }

        private void CreatePassword(string password,out byte[] hash,out byte[] salt)
        {
            using (var hmac = new HMACSHA512())
            {
                salt = hmac.Key;
                hash=hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        private bool VerifyPassword(string password, byte[] hash, byte[] salt)
        {
            using (var hmac = new HMACSHA512(salt))
            {
                var computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return computedHash.SequenceEqual(hash);
            }
        }
            
    }
    
}

