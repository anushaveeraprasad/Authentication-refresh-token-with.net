﻿using Dapper;
using JwtWebApi.Classes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace JwtWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public CourseController(IConfiguration config)
        {
            _configuration = config;
        }
        // GET: api/<CourseController>
        [HttpGet("allcourses"),AllowAnonymous]
        public async Task<ActionResult<Course>> GetAllCourses()
        {
            using(var connectionString= new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                return Ok(await connectionString.QueryAsync<Course>("Select * from Course"));
            }
        }
        // GET api/<CourseController>/specific-course/2
        [HttpGet("specific-course/{id}"), AllowAnonymous]
        public async Task<ActionResult<Course>> GetCourseById(int id)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var course =  await connectionString.QueryFirstOrDefaultAsync<Course>("Select * from Course where courseid= @Id", new { Id = id });
                return course is null ? NotFound("No such course exists") : Ok(course);
            }
        }

        // POST api/<CourseController>
        [HttpPost("add-course"), Authorize(Roles ="Admin")]
        public async Task<ActionResult<string>> AddCourse(Course course)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                
                var result = await connectionString.ExecuteAsync("insert into Course(coursename,mode) values (@CourseName,@Mode)", new { CourseName=course.CourseName, Mode=course.Mode });
                return Ok("Course Added Successfully");
            }
        }

        // PUT api/<CourseController>/update-course/5
        [HttpPut("update-course/{id}"), Authorize(Roles = "Admin")]
        public async Task<ActionResult<string>> UpdateCourse(int id, Course course)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var result = await connectionString.ExecuteAsync(
                    "UPDATE Course SET Coursename = @CourseName, Mode = @Mode WHERE CourseId = @Id",
                    new { CourseName = course.CourseName, Mode = course.Mode, Id = id });

                return result <= 0 ? NotFound("Updation Failed") : Ok("Course Updated Successfully");
            }
        }

        // DELETE api/<CourseController>/5
        [HttpDelete("remove-course/{id}"), Authorize(Roles ="Admin")]
        public async Task<ActionResult<string>> RemoveCourse(int id)
        {
            using (var connectionString = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var result = await connectionString.ExecuteAsync("Delete from Course where CourseId=@Id", new{Id = id });
                return result <= 0 ? NotFound("Deletion Failed") : Ok("Course Deleted Successfully");
            }
        }
    }
}
