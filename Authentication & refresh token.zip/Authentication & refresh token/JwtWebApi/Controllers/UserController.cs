﻿using Dapper;
using JwtWebApi.Classes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace JwtWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IConfiguration _config;
        public UserController(IConfiguration config)
        {
            _config = config;
        }
        

        // PUT api/<UserController>/5
        [HttpPut("update-user-role/{id}"), Authorize(Roles ="Admin")]
        public async Task<ActionResult> UpdateUserRole(int id,string newRole)
        {
            using(var connectionString =new SqlConnection(_config.GetConnectionString("DefaultConnection")))
            {
                var updated=await connectionString.ExecuteAsync("Update [User] set role=@NewRole where userId=@Id", new { Id = id, NewRole = newRole });
                return updated == 0 ? NotFound("User not found") : Ok("User has been assigned new Role");
            }
        }

        // DELETE api/<UserController>/5
        [HttpDelete("delete-user/{id}"), Authorize(Roles = "Admin")]
        public async Task<ActionResult> DeleteUser(int id)
        {
            using(var connectionString=new SqlConnection(_config.GetConnectionString("DefaultConnection")))
            {
                var dltUser = await connectionString.ExecuteAsync("Delete [User]  where userId=@Id", new { Id = id });
                return dltUser == 0 ? NotFound("User not found") : Ok("User has been deleted!!!");
            }
        }
    }
}
