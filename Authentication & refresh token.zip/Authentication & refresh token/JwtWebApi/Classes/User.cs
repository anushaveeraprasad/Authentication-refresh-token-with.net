﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace JwtWebApi.Classes
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public string PasswordHash { get; set; }
        [Required]
        public string PasswordSalt { get; set; }
        public string Role { get; set; }
        public string RefreshToken { get; set; } = string.Empty;
        public DateTime TokenCreated { get; set; }
        public DateTime TokenExpires { get; set; }

        [JsonIgnore]
        public virtual ICollection<Enrollment>? Enrollments { get; set; }
    }
}
