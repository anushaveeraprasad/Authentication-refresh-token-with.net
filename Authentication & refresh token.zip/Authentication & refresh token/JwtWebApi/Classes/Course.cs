﻿using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Annotations;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace JwtWebApi.Classes
{
    public class Course
    {
        [Key]
        public int CourseId { get; set; }
        [Required]
        public string CourseName { get; set; }
        public string Mode { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual ICollection<Enrollment>? Enrollments { get; set; }
    }
}
