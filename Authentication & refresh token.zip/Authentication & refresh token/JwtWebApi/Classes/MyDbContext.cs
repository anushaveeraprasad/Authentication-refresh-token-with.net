﻿//using Microsoft.EntityFrameworkCore;

//namespace JwtWebApi.Classes
//{
//    public class MyDbContext : DbContext
//    {
//        public DbSet<User> Users { get; set; }
//        private readonly IConfiguration _config;
//        public MyDbContext(IConfiguration configuration)
//        {
//            _config = configuration;
//        }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            // Configure your database connection here
//            optionsBuilder.UseSqlServer(_config.GetConnectionString("DefaultConnection"));
//        }
//    }
//}
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace JwtWebApi.Classes
{
    public class MyDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options)
        {
            // Constructor logic...
        }
    }
}

