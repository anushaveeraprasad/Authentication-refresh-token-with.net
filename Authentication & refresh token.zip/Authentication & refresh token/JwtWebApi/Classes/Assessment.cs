﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace JwtWebApi.Classes
{
    public class Assessment
    {
        [Key]
        public int AssessmentId { get; set; }
        [Required]
        public string  AssessmentName { get; set; }
        public DateTime Duration { get; set; }
        public int NumOfQuestions { get; set; }
        public DateTime StartDate { get; set; }
        [JsonIgnore]
        public virtual ICollection<Enrollment>? Enrollments { get; set; }

    }
}
