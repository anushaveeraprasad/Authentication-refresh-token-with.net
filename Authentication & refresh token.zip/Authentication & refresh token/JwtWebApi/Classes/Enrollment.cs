﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace JwtWebApi.Classes
{
    public class Enrollment
    {
        [Key]
        public int EnrollmentId { get; set; }
        public int UserId { get; set; }
        public int? CourseId { get; set; }
        public int? AssessmentId { get; set; }
        public DateTime EnrolledTime { get; set; }

        [ForeignKey("UserId")]
        public virtual User? User { get; set; }
        [ForeignKey("CourseId")]
        public virtual Course? Course { get; set; }
        [ForeignKey("AssessmentId")]
        public virtual Assessment? Assessment { get; set; }

    }
}
